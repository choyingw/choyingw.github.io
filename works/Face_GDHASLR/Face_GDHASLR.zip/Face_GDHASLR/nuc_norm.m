function y=nuc_norm(x)

y= trace( sqrt((x.')*x));
end